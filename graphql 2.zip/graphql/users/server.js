const express = require('express');
const expressGraphQL = require('express-graphql');
const schema1 = require('./schema/schema1');
const schema2 = require('./schema/schema2');
const schema3 = require('./schema/schema3');
const schema4 = require('./schema/schema4');
const schema5 = require('./schema/schema5');
const schema6 = require('./schema/schema6');
const schema7 = require('./schema/schema7');
const schema8 = require('./schema/schema8');

const app = express();
app.use(
  '/graphql',
  expressGraphQL({
    schema: schema8,
    graphiql: true,
  })
);
app.listen(4000, () => {
  console.log('listening...');
});
